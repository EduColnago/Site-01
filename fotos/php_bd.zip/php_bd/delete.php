<?php
$connection = pg_connect("host=localhost port=5432 dbname=****** user=****** password=******");

$sql = "DELETE FROM cerveja.gostam WHERE pessoa like $1";

pg_prepare("delete_cerveja_gostam", $sql);

$pessoa = "Rafael%";

$parameters = array($pessoa);

pg_execute("delete_cerveja_gostam", $parameters) 
	or die("Error while delete.");

echo "delete ok!";

pg_close($connection);
?>


