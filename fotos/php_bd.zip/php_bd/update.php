<?php
$connection = pg_connect("host=localhost port=5432 dbname=****** user=****** password=******");

$sql = "UPDATE cerveja.gostam SET pessoa = $1 WHERE pessoa like $2";

pg_prepare("update_cerveja_gostam", $sql);

$antiga_pessoa = "Rafael%";
$nova_pessoa = "Rafael Pereira";

$parameters = array($nova_pessoa, $antiga_pessoa);

pg_execute("update_cerveja_gostam", $parameters) 
	or die("Error while update.");

echo "update ok!";

pg_close($connection);
?>
