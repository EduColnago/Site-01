<?php
$connection = pg_connect("host=localhost port=5432 dbname=***** user=***** password=*****");

$sql = "INSERT INTO cerveja.gostam (pessoa, cerveja) VALUES ($1, $2)";

pg_prepare("insert_cerveja_gostam", $sql);

$pessoa = 'Rafael';
$cerveja  = 'Skol';

$parameters = array($pessoa, $cerveja);

pg_execute("insert_cerveja_gostam", $parameters) 
	or die("Error while insert.");

echo "insert ok!";

pg_close($connection);
?>


