<?php
$connection = pg_connect("host=localhost port=5432 dbname=***** user=***** password=*****");

$sql = "SELECT * FROM cerveja.gostam where pessoa like $1";
pg_prepare("select_cerveja_gostam", $sql);

$nome = "%Rafael%";
$parameters = array($nome);

$result = pg_execute("select_cerveja_gostam", $parameters);

if  (!$result) {
	echo "query did not execute";
} else if(pg_num_rows($result) == 0) {
	echo "0 records";
} else {
	while ($row = pg_fetch_array($result)) {
	     echo $row["pessoa"]." - ".$row["cerveja"]."<br>";
    	}
}
pg_close($connection);
?>


